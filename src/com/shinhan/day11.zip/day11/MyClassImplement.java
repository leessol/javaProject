package com.shinhan.day11;

public class MyClassImplement implements MyInterface{
	@Override
	public void print() {
		System.out.println("MyclassImplement에서 구현한다.....");
		
	}
}
