package com.shinhan.day11;

@FunctionalInterface
public interface Speakable {
	String speak(String content);
}
