package com.shinhan.day08;


public class ChildB extends Parent {

}
