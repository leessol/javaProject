package com.shinhan.day08;


public class ChildA extends Parent {

}
