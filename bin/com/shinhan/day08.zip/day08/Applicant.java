package com.shinhan.day08;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class Applicant <T> {
	T kind;
	
	
	
	
}
