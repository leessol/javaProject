package com.shinhan.day09;

public class MusicThread implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
